package graphicscheck;
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JFrame;
	
	public class GraphicsDemo extends JFrame {

	    // The constructor follows:
	    public GraphicsDemo() {
	        setTitle("GraphicsDemo with Kilobolt");
	        setSize(800, 480);
	        setVisible(true);
	        setDefaultCloseOperation(EXIT_ON_CLOSE);
	    }

	    public void paint(Graphics g) {
	        g.setColor(Color.PINK);
	        g.fillRect(0, 0, 800, 480);
	        g.setColor(Color.BLUE);
	        g.drawRect(20, 100, 400, 350);
	        g.setColor(Color.BLACK);
	        g.drawString("My name is Harleen", 125, 200);
	    }

	    // All classes need a main method, so we create that here too!
	    public static void main(String args[]) {
	        // We will create a GraphicsDemo object in the main method like so:
	        // This should be familar, as we used this to create Random objects and
	        // Thread objects:
	        GraphicsDemo demo = new GraphicsDemo();

	    }

	} 
